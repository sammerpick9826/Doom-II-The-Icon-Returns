NOTE: This wad is a work in progress. New maps will be
added and the level designs seen here may not be final. As
of now, there are only ten maps. I would greatly appreciate
all of the feedback, positive or negative, that I can get.
I am making walkthroughs for all of the maps here
(https://www.youtube.com/playlist?list=PLDq-COkVy4CXi-6djFDkVa-6FbnsT0jD6).
The comments sections on these videos would be the best
place to share any feedback. Thank you for reading this,
and I hope you enjoy the wad!